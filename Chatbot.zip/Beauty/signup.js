function validateSignupForm() {
    const username = document.getElementById('newUsername').value.trim();
    const email = document.getElementById('newEmail').value.trim();
    const password = document.getElementById('newPassword').value.trim();
  
    if (username === '' || email === '' || password === '') {
      alert('Please fill in all fields!');
      return false;
    }
  
    alert(`Welcome, ${username}! Your account has been created.`);
    // In real app, send data to server/database here
    return false; // Prevent actual form submission for now
  }
  