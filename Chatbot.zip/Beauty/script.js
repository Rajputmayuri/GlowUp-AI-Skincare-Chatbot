function validateForm() {
    const username = document.getElementById("username").value.trim();
  const password = document.getElementById("password").value.trim();

  if (username === "" || password === "") {
    alert("Please fill in both fields.");
    return false;
  }

  // You can add real authentication here later
  alert("Login successful!");
  window.location.href = "chat.html"; // ✅ Redirect to chat page

  return false; // Prevent default form submission
  }
  