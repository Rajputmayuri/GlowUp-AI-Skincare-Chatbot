from flask import Flask, request, jsonify
from flask_cors import CORS
import openai
import sqlite3

app = Flask(__name__)
CORS(app)

# --- OpenAI setup ---
openai.api_key = "sk-proj-..."  # Replace with your actual OpenAI API key

# --- Helper function: connect to DB ---
def get_db_connection():
    conn = sqlite3.connect("glowup_users.db")
    conn.row_factory = sqlite3.Row
    return conn

# --- Chat Endpoint ---
@app.route("/chat", methods=["POST"])
def chat():
    data = request.get_json()
    user_message = data.get("message", "")

    if not user_message.strip():
        return jsonify({"reply": "Please enter a valid skincare question."}), 400

    try:
        response = openai.ChatCompletion.create(
            model="gpt-3.5-turbo",
            messages=[
                {
                    "role": "system",
                    "content": "You are GlowUp AI, a helpful skincare and beauty advisor. Only answer questions related to beauty. If asked anything else, politely say you’re trained only for skincare."
                },
                {
                    "role": "user",
                    "content": user_message
                }
            ]
        )
        reply = response["choices"][0]["message"]["content"]
        return jsonify({"reply": reply})
    except Exception as e:
        return jsonify({"reply": "Something went wrong. Please try again later."}), 500

# --- Signup Endpoint ---
@app.route("/signup", methods=["POST"])
def signup():
    data = request.get_json()
    name = data.get("name")
    email = data.get("email")
    password = data.get("password")

    if not name or not email or not password:
        return jsonify({"status": "error", "message": "All fields are required"}), 400

    conn = get_db_connection()
    try:
        conn.execute(
            "INSERT INTO users (name, email, password) VALUES (?, ?, ?)",
            (name, email, password)
        )
        conn.commit()
        return jsonify({"status": "success", "message": "Signup successful"}), 200
    except sqlite3.IntegrityError:
        return jsonify({"status": "error", "message": "Email already registered"}), 409
    finally:
        conn.close()

# --- Login Endpoint ---
@app.route("/login", methods=["POST"])
def login():
    data = request.get_json()
    email = data.get("email")
    password = data.get("password")
    mobile_number = data.get("mobile number") # type: ignore

    if not email or not password:
        return jsonify({"status": "error", "message": "Email and password are required"}), 400

    conn = get_db_connection()
    user = conn.execute(
        "SELECT * FROM users WHERE email = ? AND password = ?",
        (email, password)
    ).fetchone()
    conn.close()

    if user:
        return jsonify({"status": "success", "message": "Login successful"}), 200
    else:
        return jsonify({"status": "error", "message": "Invalid login credentials"}), 401

# --- Run the server ---
if __name__ == "__main__":
    app.run(debug=True)
