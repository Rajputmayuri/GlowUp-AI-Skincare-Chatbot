async function sendMessage() {
  const input = document.getElementById("user-input");
  const message = input.value.trim();
  if (message === "") return;

  const chatBox = document.getElementById("chat-box");

  const userMsg = document.createElement("div");
  userMsg.className = "user-message";
  userMsg.textContent = message;
  chatBox.appendChild(userMsg);

  input.value = "";

  // Show loading...
  const botMsg = document.createElement("div");
  botMsg.className = "bot-message";
  botMsg.textContent = "Typing...";
  chatBox.appendChild(botMsg);

  chatBox.scrollTop = chatBox.scrollHeight;

  // Simulate delay
  await new Promise(resolve => setTimeout(resolve, 1000));

  // Dummy response block (replace real API)
  const data = {
    reply: "This is a test reply to: \"" + message + "\""
  };

  botMsg.textContent = data.reply;

  chatBox.scrollTop = chatBox.scrollHeight;
}
